replacements= {
      "Google": "Google©",
      "Fugro": "Fugro B.V.",
      "Holland": "The Netherlands"
    }

  